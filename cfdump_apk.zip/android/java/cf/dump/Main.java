package cf.dump;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main extends Activity {
    private static final String OUT = "/sdcard/Download/cfdump";
    private final Handler ui = new Handler(Looper.getMainLooper());
    private EditText pkg;
    private TextView log;
    private ScrollView logScroll;
    private Button go;
    private volatile boolean busy;

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(14, 16, 22));
        root.setPadding(dp(12), dp(36), dp(12), dp(12));

        TextView t = new TextView(this);
        t.setText("CF Dump  (нужен root)");
        t.setTextColor(Color.WHITE); t.setTextSize(20); t.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(t);

        TextView h = new TextView(this);
        h.setText("1) запусти игру и дойди до главного меню\n2) вернись сюда, выбери игру из списка\n3) жми DUMP, жди «done»\nрезультат: " + OUT);
        h.setTextColor(Color.rgb(170, 180, 200)); h.setTextSize(13);
        h.setPadding(0, dp(6), 0, dp(8));
        root.addView(h);

        pkg = new EditText(this);
        pkg.setHint("package (com.xxx.yyy)");
        pkg.setHintTextColor(Color.GRAY); pkg.setTextColor(Color.WHITE); pkg.setSingleLine(true);
        root.addView(pkg);

        go = new Button(this);
        go.setText("DUMP");
        go.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { start(); } });
        root.addView(go);

        ScrollView apps = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        apps.addView(list);
        root.addView(apps, new LinearLayout.LayoutParams(-1, dp(150)));
        fillApps(list);

        logScroll = new ScrollView(this);
        log = new TextView(this);
        log.setTextColor(Color.rgb(120, 230, 150)); log.setTextSize(11); log.setTypeface(Typeface.MONOSPACE);
        log.setTextIsSelectable(true);
        logScroll.addView(log);
        root.addView(logScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private void fillApps(LinearLayout list) {
        PackageManager pm = getPackageManager();
        final List<String[]> apps = new ArrayList<String[]>();
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0) {
                continue;
            }
            if (ai.packageName.equals(getPackageName())) continue;
            apps.add(new String[]{String.valueOf(pm.getApplicationLabel(ai)), ai.packageName});
        }
        Collections.sort(apps, new java.util.Comparator<String[]>() {
            public int compare(String[] a, String[] c) { return a[0].compareToIgnoreCase(c[0]); }
        });
        for (final String[] a : apps) {
            TextView r = new TextView(this);
            r.setText(a[0] + "\n" + a[1]);
            r.setTextColor(Color.rgb(210, 215, 230)); r.setTextSize(12);
            r.setPadding(dp(6), dp(5), dp(6), dp(5));
            r.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pkg.setText(a[1]); } });
            list.addView(r);
        }
    }

    private void out(final String s) {
        ui.post(new Runnable() { public void run() { log.append(s + "\n"); logScroll.post(new Runnable() { public void run() { logScroll.fullScroll(View.FOCUS_DOWN); } }); } });
    }

    private void start() {
        final String p = pkg.getText().toString().trim();
        if (p.length() == 0) { out("выбери игру"); return; }
        if (busy) return;
        busy = true; go.setEnabled(false); log.setText("");
        new Thread(new Runnable() { public void run() { try { work(p); } catch (Throwable e) { out("ERR " + e); } busy = false; ui.post(new Runnable() { public void run() { go.setEnabled(true); } }); } }).start();
    }

    private void work(String p) throws Exception {
        File bin = new File(getFilesDir(), "cf_dump");
        InputStream in = getAssets().open("cf_dump");
        OutputStream os = new FileOutputStream(bin);
        byte[] buf = new byte[65536]; int n;
        while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        os.close(); in.close();
        String sh = "cp '" + bin.getAbsolutePath() + "' /data/local/tmp/cf_dump && chmod 755 /data/local/tmp/cf_dump"
                + " && mkdir -p " + OUT + " && /data/local/tmp/cf_dump '" + p + "' " + OUT + " 2>&1";
        out("> su: dump " + p);
        Process pr = new ProcessBuilder("su", "-c", sh).redirectErrorStream(true).start();
        BufferedReader r = new BufferedReader(new InputStreamReader(pr.getInputStream()));
        String l;
        while ((l = r.readLine()) != null) out(l);
        int rc = pr.waitFor();
        out(rc == 0 ? "== готово: " + OUT + " (в MT Manager: сожми папку и скинь)" : "== код " + rc + " (root выдан? игра запущена?)");
    }
}
