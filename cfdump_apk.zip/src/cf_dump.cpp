// cf_dump: root memory dumper for il2cpp games (libil2cpp image, global-metadata, unity version)
// usage: su -c "./cf_dump <package|pid> <outdir>"   (run AFTER the game reached the main menu)
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <errno.h>
#include <cstdarg>

struct Reg { uint64_t a, b, off; bool r, w, x; std::string path; };
static int g_pid = 0, g_memfd = -1;
static FILE* g_info = nullptr;

static void say(const char* fmt, ...) __attribute__((format(printf, 1, 2)));
static void say(const char* fmt, ...) {
    char buf[1024];
    va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    fputs(buf, stdout); fflush(stdout);
    if (g_info) { fputs(buf, g_info); fflush(g_info); }
}

static size_t rd(uint64_t addr, void* dst, size_t n) {
    size_t got = 0;
    while (got < n) {
        iovec l{(char*)dst + got, n - got}, r{(void*)(addr + got), n - got};
        ssize_t k = process_vm_readv(g_pid, &l, 1, &r, 1, 0);
        if (k > 0) { got += (size_t)k; continue; }
        // page by page fallback via /proc/pid/mem
        if (g_memfd >= 0) {
            ssize_t m = pread64(g_memfd, (char*)dst + got, n - got, (off64_t)(addr + got));
            if (m > 0) { got += (size_t)m; continue; }
        }
        break;
    }
    return got;
}

static std::vector<Reg> read_maps() {
    std::vector<Reg> v;
    char p[64]; snprintf(p, sizeof p, "/proc/%d/maps", g_pid);
    FILE* f = fopen(p, "r"); if (!f) return v;
    char line[1024];
    while (fgets(line, sizeof line, f)) {
        unsigned long long a, b, off; char perms[8] = {0}; int n = 0;
        if (sscanf(line, "%llx-%llx %7s %llx %*s %*s %n", &a, &b, perms, &off, &n) < 4) continue;
        Reg r; r.a = a; r.b = b; r.off = off;
        r.r = perms[0] == 'r'; r.w = perms[1] == 'w'; r.x = perms[2] == 'x';
        if (n > 0) { r.path = line + n; while (!r.path.empty() && (r.path.back() == '\n' || r.path.back() == ' ')) r.path.pop_back(); }
        v.push_back(r);
    }
    fclose(f);
    return v;
}

static int find_pid(const char* s) {
    char* e; long v = strtol(s, &e, 10);
    if (*s && !*e && v > 0) return (int)v;
    DIR* d = opendir("/proc"); if (!d) return 0;
    int best = 0; dirent* de;
    std::string want = s;
    while ((de = readdir(d))) {
        int pid = atoi(de->d_name); if (pid <= 0) continue;
        char p[64]; snprintf(p, sizeof p, "/proc/%d/cmdline", pid);
        FILE* f = fopen(p, "r"); if (!f) continue;
        char buf[512] = {0}; size_t n = fread(buf, 1, sizeof buf - 1, f); fclose(f); (void)n;
        std::string c = buf;
        if (c == want) { best = pid; break; }
        if (!best && c.compare(0, want.size(), want) == 0) best = pid;
    }
    closedir(d);
    return best;
}

static bool write_range(const std::string& out, uint64_t a, uint64_t n, size_t* unread = nullptr) {
    FILE* f = fopen(out.c_str(), "wb"); if (!f) return false;
    std::vector<char> buf(1 << 20);
    size_t bad = 0;
    for (uint64_t o = 0; o < n; o += buf.size()) {
        size_t c = (size_t)std::min<uint64_t>(buf.size(), n - o);
        size_t g = rd(a + o, buf.data(), c);
        if (g < c) { memset(buf.data() + g, 0, c - g); bad += c - g; }
        fwrite(buf.data(), 1, c, f);
    }
    fclose(f);
    if (unread) *unread = bad;
    return true;
}

// ---- il2cpp metadata ----
static bool meta_size(const uint8_t* h, size_t have, uint64_t* total, int* ver, uint32_t* hdr) {
    uint32_t magic, version; memcpy(&magic, h, 4); memcpy(&version, h + 4, 4);
    if (magic != 0xFAB11BAF) return false;
    if (version < 20 || version > 40) return false;
    uint32_t first; memcpy(&first, h + 8, 4);          // stringLiteralOffset == header size
    if (first < 0xE0 || first > 0x300 || (first & 7)) return false;
    if (have < first) return false;
    uint64_t mx = first;
    for (uint32_t i = 8; i + 8 <= first; i += 8) {
        uint32_t off, sz; memcpy(&off, h + i, 4); memcpy(&sz, h + i + 4, 4);
        if (off > (1u << 30) || sz > (1u << 30)) continue;       // not a plain pair (or encrypted)
        if (off && (uint64_t)off + sz > mx) mx = (uint64_t)off + sz;
    }
    *total = mx; *ver = (int)version; *hdr = first;
    return mx > first && mx < (1ull << 31);
}

int main(int argc, char** argv) {
    if (argc < 3) { fprintf(stderr, "usage: cf_dump <package|pid> <outdir>\n"); return 2; }
    g_pid = find_pid(argv[1]);
    if (!g_pid) { fprintf(stderr, "game not running: %s (open it first, wait for the menu)\n", argv[1]); return 1; }
    std::string od = argv[2];
    mkdir(od.c_str(), 0777);
    g_info = fopen((od + "/info.txt").c_str(), "w");
    char mp[64]; snprintf(mp, sizeof mp, "/proc/%d/mem", g_pid);
    g_memfd = open(mp, O_RDONLY);
    say("pid=%d\n", g_pid);

    auto regs = read_maps();
    if (regs.empty()) { say("cannot read maps (need root)\n"); return 1; }
    say("regions=%zu\n", regs.size());
    { FILE* f = fopen((od + "/maps.txt").c_str(), "w"); char p[64]; snprintf(p, sizeof p, "/proc/%d/maps", g_pid);
      FILE* s = fopen(p, "r"); if (f && s) { char b[1024]; while (fgets(b, sizeof b, s)) fputs(b, f); } if (f) fclose(f); if (s) fclose(s); }

    // ---- 1. libil2cpp image ----
    uint64_t lo = ~0ull, hi = 0; int nseg = 0;
    for (auto& r : regs) if (r.path.find("libil2cpp.so") != std::string::npos) {
        nseg++; lo = std::min(lo, r.a); hi = std::max(hi, r.b);
        say("il2cpp seg %llx-%llx %c%c%c off=%llx\n", (unsigned long long)r.a, (unsigned long long)r.b, r.r ? 'r' : '-', r.w ? 'w' : '-', r.x ? 'x' : '-', (unsigned long long)r.off);
    }
    if (nseg) {
        uint64_t sz = hi - lo;
        std::string fn = od + "/libil2cpp_dump.so";
        FILE* f = fopen(fn.c_str(), "wb");
        std::vector<char> buf(1 << 20);
        uint64_t unread = 0;
        for (uint64_t o = 0; o < sz; o += buf.size()) {
            size_t c = (size_t)std::min<uint64_t>(buf.size(), sz - o);
            // zero everything not inside a readable region
            memset(buf.data(), 0, c);
            for (auto& r : regs) {
                if (!r.r) continue;
                uint64_t s = std::max(r.a, lo + o), e = std::min(r.b, lo + o + c);
                if (s >= e) continue;
                size_t g = rd(s, buf.data() + (s - lo - o), (size_t)(e - s));
                unread += (e - s) - g;
            }
            fwrite(buf.data(), 1, c, f);
        }
        fclose(f);
        uint32_t m4 = 0; rd(lo, &m4, 4);
        say("LIBIL2CPP base=0x%llx size=0x%llx unread=%llu head=%s\n", (unsigned long long)lo, (unsigned long long)sz, (unsigned long long)unread, m4 == 0x464C457F ? "ELF" : "NOT-ELF(header wiped)");
        FILE* b = fopen((od + "/il2cpp_base.txt").c_str(), "w"); if (b) { fprintf(b, "%llx\n", (unsigned long long)lo); fclose(b); }
    } else say("no libil2cpp.so mapping by name (custom loader?) -> scanning anon ELFs\n");

    // anon ELF images (packed/custom-loaded libs)
    int elfn = 0;
    for (size_t i = 0; i < regs.size(); i++) {
        auto& r = regs[i];
        if (!r.r || (!r.path.empty() && r.path[0] == '/')) continue;
        uint32_t m = 0; if (rd(r.a, &m, 4) != 4 || m != 0x464C457F) continue;
        uint64_t e = r.b; size_t j = i + 1;
        while (j < regs.size() && regs[j].a == e && (regs[j].path.empty() || regs[j].path[0] != '/')) { e = regs[j].b; j++; }
        if (e - r.a < (256u << 10)) continue;
        char fn[128]; snprintf(fn, sizeof fn, "/anon_elf_%llx.so", (unsigned long long)r.a);
        size_t bad = 0; write_range(od + fn, r.a, e - r.a, &bad);
        say("ANON-ELF base=0x%llx size=0x%llx unread=%zu -> %s\n", (unsigned long long)r.a, (unsigned long long)(e - r.a), bad, fn + 1);
        elfn++;
    }

    // ---- 2. global-metadata ----
    int metan = 0;
    std::vector<uint8_t> chunk((1 << 20) + 8);
    const uint8_t magic[4] = {0xAF, 0x1B, 0xB1, 0xFA};
    for (auto& r : regs) {
        if (!r.r) continue;
        if (r.path.compare(0, 5, "/dev/") == 0 || r.path == "[vvar]" || r.path == "[vsyscall]") continue;
        if (r.path.find(".so") != std::string::npos && !r.w) continue;      // code libs: skip
        for (uint64_t o = r.a; o < r.b; o += (1 << 20)) {
            size_t c = (size_t)std::min<uint64_t>((1 << 20) + 8, r.b - o);
            size_t g = rd(o, chunk.data(), c);
            if (g < 8) continue;
            for (size_t k = 0; k + 4 <= g && k < (1 << 20); k++) {
                if (chunk[k] != magic[0]) continue;
                if (memcmp(&chunk[k], magic, 4)) continue;
                uint8_t hd[0x300]; uint64_t at = o + k;
                size_t hg = rd(at, hd, sizeof hd);
                uint64_t tot; int ver; uint32_t hdr;
                if (!meta_size(hd, hg, &tot, &ver, &hdr)) continue;
                char fn[128]; snprintf(fn, sizeof fn, "/metadata_%llx.dat", (unsigned long long)at);
                size_t bad = 0; write_range(od + fn, at, tot, &bad);
                say("METADATA addr=0x%llx ver=%d hdr=0x%x size=0x%llx unread=%zu region=%s -> %s\n", (unsigned long long)at, ver, hdr, (unsigned long long)tot, bad, r.path.empty() ? "[anon]" : r.path.c_str(), fn + 1);
                metan++;
            }
        }
    }
    if (!metan) say("METADATA not found in RAM (magic AF1BB1FA absent: header decrypted lazily or custom format)\n");

    // ---- 3. unity version ----
    std::map<std::string, int> vers;
    for (auto& r : regs) {
        if (!r.r || r.path.find("libunity.so") == std::string::npos || r.w || r.x) continue;
        std::vector<char> b(r.b - r.a);
        size_t g = rd(r.a, b.data(), b.size());
        for (size_t i = 0; i + 12 < g; i++) {
            if (!(b[i] >= '0' && b[i] <= '9') || (i && b[i - 1] >= '0' && b[i - 1] <= '9')) continue;
            size_t p = i; int d = 0;
            while (p < g && b[p] >= '0' && b[p] <= '9') { p++; d++; }
            if (d != 4 || p >= g || b[p] != '.') continue;
            p++; int d2 = 0; while (p < g && b[p] >= '0' && b[p] <= '9') { p++; d2++; }
            if (!d2 || p >= g || b[p] != '.') continue;
            p++; int d3 = 0; while (p < g && b[p] >= '0' && b[p] <= '9') { p++; d3++; }
            if (!d3 || p + 1 >= g || (b[p] != 'f' && b[p] != 'p' && b[p] != 'b' && b[p] != 'a')) continue;
            p++; int d4 = 0; while (p < g && b[p] >= '0' && b[p] <= '9') { p++; d4++; }
            if (!d4) continue;
            std::string s(&b[i], p - i);
            if (s.size() < 20 && s.compare(0, 2, "20") == 0) vers[s]++;
        }
    }
    for (auto& kv : vers) say("UNITY %s x%d\n", kv.first.c_str(), kv.second);
    if (vers.empty()) say("UNITY version string not found in libunity.so\n");

    // protection hints
    static const char* sus[] = {"libmhp", "tersafe", "anogs", "NetHTProtect", "libuprotect", "libDexHelper", "libjiagu", "libsecneo", "libbangcle", "libshella", "libmsaoaidsec", "libnesec", "libEOSSDK", "libcrashsight", "libgcloud", "libTDataMaster", "libtprt", "libmsec", "libdunamis", nullptr};
    std::vector<std::string> seen;
    for (auto& r : regs) for (int i = 0; sus[i]; i++) if (r.path.find(sus[i]) != std::string::npos && std::find(seen.begin(), seen.end(), r.path) == seen.end()) seen.push_back(r.path);
    for (auto& s : seen) say("PROTECT-LIB %s\n", s.c_str());
    say("done: il2cpp=%d anon_elf=%d metadata=%d\n", nseg ? 1 : 0, elfn, metan);
    if (g_info) fclose(g_info);
    return 0;
}
